webpackHotUpdate(0,{

/***/ 86:
/***/ function(module, exports, __webpack_require__) {

"use strict";
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var React = __webpack_require__(84);
var Demo = (function (_super) {
    __extends(Demo, _super);
    function Demo(props, context) {
        return _super.call(this, props, context) || this;
    }
    Demo.prototype.render = function () {
        return (React.createElement("div", null,
            "start",
            React.createElement("img", { src: "./static/qi.jpg", style: { width: "100px" } }),
            "         f"));
    };
    return Demo;
}(React.Component));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Demo;
//# sourceMappingURL=Demo.js.map

/***/ }

})
//# sourceMappingURL=0.b37374e44ed0821c29ee.hot-update.js.map